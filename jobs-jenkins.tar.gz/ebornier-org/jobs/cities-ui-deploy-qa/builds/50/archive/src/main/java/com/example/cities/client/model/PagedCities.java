package com.example.cities.client.model;

import com.example.cities.client.model.City;

import org.springframework.hateoas.PagedResources;

public class PagedCities extends PagedResources<City> {

}
